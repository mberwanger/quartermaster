# Knowledge store

Every document in the store, concatenated in path order. Each block is preceded by its path, which carries information the prose does not.
